package com.mycompany.app.graph;

public interface IGraphFactory {
  IGraph newGraph(String title);
}