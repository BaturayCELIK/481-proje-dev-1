class A {
	void z() {
		int x = 0;
		int y = 1;
		if (x < y) {
			int z = 0;
			int t = 5;
		}
		int q = 1;
	}
}