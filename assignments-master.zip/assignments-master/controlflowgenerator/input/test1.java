class A {
	void t() {
		int x = 0;
		int y = 1;
		int q = 1;
	}
}