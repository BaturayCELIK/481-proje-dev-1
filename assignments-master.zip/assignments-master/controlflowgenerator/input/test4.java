class A {
	void z() {
		int x = 0;
		int y = 1;
		if (x < y) {
			int z = 0;
			int t = 5;
			if (z < t) {
				int a = 1;
				int b = 2;
			}
		}
		int q = 1;
	}
}