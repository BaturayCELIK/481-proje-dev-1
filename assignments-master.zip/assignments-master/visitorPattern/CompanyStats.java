/**
* A visitor that prints the company stats.
*/
public class CompanyStats implements IVisitor {
	/* ADD YOUR IMPLEMENTATION HERE*/	
}