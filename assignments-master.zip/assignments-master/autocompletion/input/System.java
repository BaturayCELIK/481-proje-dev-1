public class System {
     public void arraycopy(Object src, int srcPos, Object dest, int destPos, int length) {}
     public String	clearProperty(String key) { return ""; }
     public long	currentTimeMillis() { return 0; }
     public void	exit(int status) {}
     public void	gc() {}
     public Map<String,String>	getenv() { return null; }
     public String	getenv(String name) { return ""; }
     public Properties	getProperties() { return null; }
     public String	getProperty(String key) { return ""; }
     public String	getProperty(String key, String def) { return ""; }
     public SecurityManager	getSecurityManager() { return null; }  
     private void getProperty2() {}
}