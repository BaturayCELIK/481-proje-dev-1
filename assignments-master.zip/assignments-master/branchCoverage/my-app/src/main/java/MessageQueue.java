public interface MessageQueue {
  public String getAt(int i);
  public boolean contains(String s);
  public int size();
}